// public header

#pragma once

#include "Bot.h" // bot object, create this one
#include "CurlHttpClient.h" // http client tuning, remove? not everyone needs this
#include "EventBroadcaster.h" // set callbacks
